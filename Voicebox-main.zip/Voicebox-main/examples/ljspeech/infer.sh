#!/usr/bin/env bash

# Set bash to 'debug' mode, it will exit on :
# -e 'error', -u 'undefined variable', -o ... 'error in pipeline', -x 'print commands',
set -e
#set -u
set -o pipefail

. ./path.sh || exit 1;

export CUDA_VISIBLE_DEVICES="0"


python infer.py
