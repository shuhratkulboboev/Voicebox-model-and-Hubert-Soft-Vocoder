#!/usr/bin/env python

from setuptools import setup, find_packages

setup(
    name='soundstorm',
    version='0.0.0',
    description='Describe Your Cool Project',
    author='',
    author_email='',
    # REPLACE WITH YOUR OWN GITHUB PROJECT LINK
    url='https://github.com/chenht2010/lightning-project-template',
    install_requires=['lightning'],
    packages=find_packages(),
)

